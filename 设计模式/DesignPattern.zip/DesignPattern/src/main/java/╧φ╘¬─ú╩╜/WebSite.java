package 享元模式;

public abstract class WebSite {
    public abstract void use(User user);
}
