package 模板方法模式;

public class PeanutSoyaMilk extends SoyaMilk{
    @Override
    public void add() {
        System.out.println("加花生");
    }
}
