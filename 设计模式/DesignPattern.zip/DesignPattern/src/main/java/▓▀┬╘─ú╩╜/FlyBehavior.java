package 策略模式;

public interface FlyBehavior {
    void fly();
}
