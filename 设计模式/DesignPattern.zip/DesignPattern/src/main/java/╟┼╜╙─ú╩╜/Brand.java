package 桥接模式;

public interface Brand {
    void call();
    void close();
    void open();
}
