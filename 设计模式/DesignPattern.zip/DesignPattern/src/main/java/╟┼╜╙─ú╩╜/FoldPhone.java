package 桥接模式;

public class FoldPhone extends Phone{
    public FoldPhone(Brand brand) {
        super(brand);
    }

    public void open(){
        System.out.println("弯手机");
        super.open();
    }

    public void close(){
        System.out.println("弯手机");
        super.close();
    }
    public void call(){
        System.out.println("弯手机");
        super.call();
    }
}
