package 装饰者模式;

public class Espresso extends Coffee{
    public Espresso() {
        setDescription("Espresso");
        setPrice(6d);
    }
}
