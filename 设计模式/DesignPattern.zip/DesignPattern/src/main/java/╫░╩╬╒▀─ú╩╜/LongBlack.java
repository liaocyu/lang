package 装饰者模式;

public class LongBlack extends Coffee{
    public LongBlack() {
        setDescription("LongBlack");
        setPrice(12d);
    }
}
