package 装饰者模式;

public class ShortBlack extends Coffee{
    public ShortBlack() {
        setDescription("ShortBlack");
        setPrice(24d);
    }
}
