package 访问者模式;


public abstract class Person {
    public abstract void accept(Action action);
}
