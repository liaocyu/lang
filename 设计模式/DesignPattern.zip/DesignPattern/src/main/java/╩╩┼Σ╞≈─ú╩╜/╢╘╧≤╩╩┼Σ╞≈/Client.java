package 适配器模式.对象适配器;

public class Client {

    public static void main(String[] args) {
        //对象适配器
        Phone phone = new Phone();
        phone.charge(new VoltageAdapter(new Voltage220V()));
    }
}
