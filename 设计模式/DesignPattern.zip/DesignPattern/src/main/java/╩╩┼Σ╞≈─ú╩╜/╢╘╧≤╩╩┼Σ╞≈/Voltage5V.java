package 适配器模式.对象适配器;

//适配接口
public interface Voltage5V {
    int output5V();
}
