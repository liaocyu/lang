package 适配器模式.接口适配器;

//将所有接口方法进行空实现
public abstract class Abstract implements Interface{
    @Override
    public void m1() {

    }

    @Override
    public void m2() {

    }

    @Override
    public void m3() {

    }

    @Override
    public void m4() {

    }
}
