package 适配器模式.接口适配器;

public interface Interface {
    void m1();
    void m2();
    void m3();
    void m4();

}
