package 适配器模式.类适配器;

//适配接口
public interface Voltage5V {
    int output5V();
}
