package 观察者模式;

public interface Observer {
    void update(float temperature,float pressure,float humidity);
}
