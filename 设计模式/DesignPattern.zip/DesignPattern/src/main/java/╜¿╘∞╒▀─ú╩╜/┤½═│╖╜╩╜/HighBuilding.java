package 建造者模式.传统方式;

public class HighBuilding extends AbstractBuilding{

    @Override
    public void buildBasic() {

    }

    @Override
    public void buildWalls() {

    }

    @Override
    public void buildRoof() {

    }
}
