package 代理模式.静态代理;

public interface ITeacherDao {
    void teach();
}
