package 代理模式.CGlib代理;

public class TeacherDao {
    public void teach(){
        System.out.println("CGlib实现代理");
    }
}
