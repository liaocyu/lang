package cn.itcast.jvm.t3.load;

public class TestFinal {

    public final void test() {

    }

    public static void main(String[] args) {
        TestFinal testFinal = new TestFinal();
        testFinal.test();

    }
}
