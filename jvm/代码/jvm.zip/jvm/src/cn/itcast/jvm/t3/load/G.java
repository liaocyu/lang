package cn.itcast.jvm.t3.load;

public class G {
    static {
//        System.out.println("ext G init");
        System.out.println("classpath G init");
    }
}
