package cn.itcast.jvm.t4;

import java.util.List;

public interface MyService {

    void save(User user);

    List<User> findAll();

}
