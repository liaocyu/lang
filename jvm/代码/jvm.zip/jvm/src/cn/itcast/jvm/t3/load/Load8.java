package cn.itcast.jvm.t3.load;

// 演示 final 对静态变量的影响
public class Load8 {

    static int a;
    static int b = 10;
    static final int c = 20;
    static final String d = "hello";
    static final Object e = new Object();
}
