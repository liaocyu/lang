package cn.itcast.jvm.t4.proxy;

public interface Advice {
}
