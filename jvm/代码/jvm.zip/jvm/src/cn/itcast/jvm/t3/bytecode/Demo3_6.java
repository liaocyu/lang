package cn.itcast.jvm.t3.bytecode;

public class Demo3_6 {
    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {

        }
    }
}
