package cn.itcast.jvm.t3.candy;


public class Candy1 {
    public Candy1() {
        super();
    }
}
