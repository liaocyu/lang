package cn.itcast.jvm.t2;

/*
查看虚拟机运行参数
"C:\Program Files\Java\jdk1.8.0_91\bin\java" -XX:+PrintFlagsFinal -version | findstr "GC"
 */
public class Demo2_8 {
}
