package cn.itcast.jvm.t3.candy;

public class Candy2 {
    public static void main(String[] args) {
        Integer x = 1;
        int y = x;
    }
}
