# JUC(java.util.concurrent并发)



> JUC指的是java.util.concurrent，主要就是三大包：
>
> 1. java.util.concurrent
> 2. java.util.concurrent.atomic
> 3. java.util.concurrent.locks



## 什么是并发、并行？

并发（concurrency）和并行（parallellism）是：

1. 并行是指两个或者多个事件在同一时刻发生；而并发是指两个或多个事件在同一时间间隔发生。
2. 并行是在不同实体上的多个事件，并发是在同一实体上的多个事件。
3. 并行是在多台处理器上同时处理多个任务。如 hadoop 分布式集群，并发是在一台处理器上“同时”处理多个任务。





## lock类案例（卖票）

> 在高内聚低耦合的条件下， 线程 -》   操作 -》   资源类

```java
package cn.qqncn;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author zkw
 * @Description 三个售票员，卖出30张票
 * 在高内聚低耦合的条件下， 线程 -》   操作 -》   资源类
 * @createTime 2021年06月25日 16:57:00
 */
public class SaleTicket {
    public static void main(String[] args) {
        Ticket ticket = new Ticket();

        new Thread(() -> {
            for (int i = 0; i < 40; i++) {
                ticket.sale();
            }
        }, "A").start();
        new Thread(() -> {
            for (int i = 0; i < 40; i++) {
                ticket.sale();
            }
        }, "B").start();
    }
}

//资源类
class Ticket {
    private int number = 30;
    Lock lock = new ReentrantLock();

    /**
     * 售票方法
     * 对资源的操作应该由资源自己定义
     */
    public void sale() {
        lock.lock();
        try {
            if (number > 0) {
                System.out.println(Thread.currentThread().getName()+"正在出售第" + number-- + "张票，当前剩余" + number + "张");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }
}



```





## 虚假唤醒

### 例子

> wait（）是object类自带的方法，在jdk有介绍，有可能出现==中断、虚假唤醒==
>
> ![image-20210627130741620](尚硅谷JUC.assets/image-20210627130741620.png)
>
> 也就是在下面的例子中
>
> ```java
> if(number != 0){
>     this.wait();
> }
> ```
>
> 当线程成功进入if语句块中，发生了中断，cpu跑去调度别的进程了，再次调度这个线程的时候，应该需要再经历一次if的判断，但是并没有这样做。
>
> 于是下面的程序运行结果：
>
> ![image-20210627131632500](尚硅谷JUC.assets/image-20210627131632500.png)



```java
package cn.qqncn;

/**
 * @author zkw
 * @Description TODO
 * @createTime 2021年06月27日 12:35:00
 */
public class ThreadWaitNotify {
    public static void main(String[] args) {
        Resource resource = new Resource();
        //increment
        new Thread(()->{
            for (int i = 0; i < 10; i++) {
                try {
                    resource.increment();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        },"A-1").start();
        new Thread(()->{
            for (int i = 0; i < 10; i++) {
                try {
                    resource.increment();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        },"A-2").start();

        //decrement
        new Thread(()->{
            for (int i = 0; i < 10; i++) {
                try {
                    resource.decrement();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        },"B-1").start();
        new Thread(()->{
            try {
                resource.decrement();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        },"B-2").start();
    }

}

class Resource{
    private int number = 0;

    //number++
    public synchronized void increment() throws InterruptedException {
        if(number != 0){
            this.wait();
        }
        number++;
        System.out.println(Thread.currentThread().getName()+":"+number);
        this.notifyAll();
    }
    //number--
    public synchronized void decrement() throws InterruptedException {
        if(number == 0){
            this.wait();
        }
        number--;
        System.out.println(Thread.currentThread().getName()+":"+number);
        this.notifyAll();
    }


}
```



### 解决办法

按照jdk文档的指示，应该将if换成while

```java
        while(number == 0){
            this.wait();
        }
```

修改后，正确的运行结果如下：

![image-20210627131858600](尚硅谷JUC.assets/image-20210627131858600.png)





## await() signal() 和 signalAll()、wait() 与 await()

**wait() 和 sleep() 的区别**
		**同**：

1. 都是线程同步时会用到的方法，使当前线程暂停运行，把机会交给其他线程

   2.如果任何线程在等待期间被中断都会抛出InterruptedException

   3.都是native() 方法

**异：**

1. wait() 是Object超类中的方法；而sleep()是线程Thread类中的方法

2. 对锁的持有不同，wait()会释放锁，而sleep()并不释放锁

3. 唤醒方法不完全相同，wait() 依靠notify或者notifyAll 、中断、达到指定时间来唤醒；而sleep()到达指定时间被唤醒.

4. 使用位置不同，wait只能在同步代码块或同步控制块中使用，而sleep可以在任何位置使用。






**await() signal() 和 signalAll()**

java.util.concurrent类库中提供的==Condition==类来实现线程之间的协调。

**在Condition上调用 await() 方法使线程等待，其他线程调用signal() 或 signalAll() 方法唤醒等待的线程。**

ReentrantLock里面默认有实现==newCondition()方法==，新建一个条件对象。

使用Lock来获取一个Condition对象，使用重入锁ReentrantLock。






**wait() 与 await()**

1. wait()是Object超类中的方法，而await()是ConditionObject类里面的方法.
2. await会导致当前线程被阻塞，会释放锁，这点和wait是一样的
3. ==await中的lock不再使用synchronized把代码同步包装起来==
4. await的阻塞需要另外的一个对象condition
5. ==notify是用来唤醒使用wait的线程；而signal是用来唤醒await线程。==
6. ==所在的超类不同使用场景也不同，wait一般用于Synchronized中，而await**只能用于ReentrantLock锁**中





## await和signalAll案例

> await和signalAll都是Condition类中的方法
>
> * 在**synchronized**  中 可以使用的是wait和notify
> * 而在**lock**同步锁中  只能使用 await 和signal

```java

class Resource{
    private int number = 0;
    private Lock lock = new ReentrantLock();
    private Condition condition = lock.newCondition();
    //number++
    public void increment() throws InterruptedException {
        lock.lock();
        try {
            while(number != 0){
                condition.await();
            }
            number++;
            System.out.println(Thread.currentThread().getName()+":"+number);
            condition.signalAll();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }
    //number--
    public  void decrement() throws InterruptedException {
        lock.lock();
        try {
            while(number == 0){
                condition.await();
            }
            number--;
            System.out.println(Thread.currentThread().getName()+":"+number);
            condition.signalAll();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }


}
```





## 精准唤醒

> JUC那套 lock、await、signal和 Object那套  synchronized、wait、notify的区别：
>
> **condition这一套能实现精确唤醒某一个线程**，而不是像notifyAll那样唤醒全部线程。

下面这个例子中，一共创建了三个Condition，可以根据业务对这三个Condition依次唤醒。来达到精准唤醒的功能

```java
package cn.qqncn;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author zkw
 * @Description 线程顺序访问
 *  多线程之间的顺序调用  A-》B-》C
 *  三个线程启动，要求如下：
 *  AA打印5次，BB打印10次，CC打印15次
 *  接着
 *  AA打印5次，BB打印10次，CC打印15次
 *  ....来10轮
 *
 *  1 高内聚低耦合的前提下，线程 操作 资源类
 *  2 判断/干活/通知
 *  3 多线程交互中，必须要防止多线程的虚假唤醒，也即（判断只用while不用if）
 *  4 标志位
 * @createTime 2021年06月27日 15:27:00
 */
public class ThreadOrderAccess {
    public static void main(String[] args) {
        ShareResource shareResource = new ShareResource();
        new Thread(()->{
            try {
                for (int i = 0; i < 10; i++) {
                    shareResource.printf5();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        },"Thread1").start();
        new Thread(()->{
            try {
                for (int i = 0; i < 10; i++) {
                    shareResource.printf10();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        },"Thread2").start();
        new Thread(()->{
            try {
                for (int i = 0; i < 10; i++) {
                    shareResource.printf15();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        },"Thread3").start();
    }
}

class ShareResource{
    private int number = 1; //1:A    2:B    3C
    private Lock lock = new ReentrantLock();
    private Condition condition1 = lock.newCondition();
    private Condition condition2 = lock.newCondition();
    private Condition condition3 = lock.newCondition();
    public void printf5() throws InterruptedException {
        lock.lock();
        try {
            while (number!=1){
                condition1.await();
            }
            for (int i = 0; i < 5; i++) {
                System.out.println(Thread.currentThread().getName()+"--AA");
            }
            number = 2;
            condition2.signal();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public void printf10() throws InterruptedException {
        lock.lock();
        try {
            while (number!=2){
                condition2.await();
            }
            for (int i = 0; i < 10; i++) {
                System.out.println(Thread.currentThread().getName()+"--BB");
            }
            number = 3;
            condition3.signal();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public void printf15() throws InterruptedException {
        lock.lock();
        try {
            while (number!=3){
                condition3.await();
            }
            for (int i = 0; i < 15; i++) {
                System.out.println(Thread.currentThread().getName()+"--CC");
            }
            number = 1;
            condition1.signal();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }
}

```



## synchronized解读

对于普通同步方法，锁的是这个对像；对于静态同步方法，锁的是这个类。

无static

> 一个对象里面如果有多个synchronized方法，某一个时刻内，只要一个线程去调用其中的一个synchronized方法了，其它的线程都只能等待，换句话说，某一个时刻内，只能有唯一一个线程去访问这些synchronized方法
> 锁的是当前对象this，被锁定后，其它的线程都不能进入到当前对象的其它的synchronized方法

有static   

> ​	当synchronized修饰的是static的方法或属性，则这个synchronized锁的不是this，而是这个类,即.class。







## ArrayList不安全

ArrayList中的add方法没有synchronized修饰，是不安全的

<img src="尚硅谷JUC.assets/image-20210627232450459.png" alt="image-20210627232450459" style="zoom:67%;" />

下面代码运行结果（异常 ==java.util.ConcurrentModificationException==）：

<img src="尚硅谷JUC.assets/image-20210627232924065.png" alt="image-20210627232924065" style="zoom:67%;" />

```java
package cn.qqncn;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * @author zkw
 * @Description list不安全
 * @createTime 2021年06月27日 22:56:00
 */
public class ThreadList {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            new Thread(()->{
                list.add(UUID.randomUUID().toString().substring(0,8));
                System.out.println(list);
            }, i+"").start();
        }
    }
}

```



#### 解决方法

> 1. 使用Vector  (已过时) 使用的是synchronized机制
>
> 2. 使用Collections.synchronizedList()方法修饰ArrayList （性能不高）
>
>    Collections中还有synchronizedMap和synchronizedSet的方法，可以修饰线程不安全的HashSet，HashMap
>
> 3. 使用==java.util.concurrent.CopyOnWriteArrayList==（推荐）使用的是lock锁

使用CopyOnWriteArrayList

底层使用的是`ReentrantLock`可重用锁

下面给出CopyOnWriteArrayList 的 add源码

```java
    final transient ReentrantLock lock = new ReentrantLock();    
	/**
     * Appends the specified element to the end of this list.
     *
     * @param e element to be appended to this list
     * @return {@code true} (as specified by {@link Collection#add})
     */
    public boolean add(E e) {
        final ReentrantLock lock = this.lock;
        lock.lock();
        try {
            Object[] elements = getArray();
            int len = elements.length;
            Object[] newElements = Arrays.copyOf(elements, len + 1);
            newElements[len] = e;
            setArray(newElements);
            return true;
        } finally {
            lock.unlock();
        }
    }
```

案例运行结果：

![image-20210627233356353](尚硅谷JUC.assets/image-20210627233356353.png)

案例源码：

```java
package cn.qqncn;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author zkw
 * @Description list不安全
 * @createTime 2021年06月27日 22:56:00
 */
public class ThreadList {
    public static void main(String[] args) {
        List<String> list = new CopyOnWriteArrayList<>();
        for (int i = 0; i < 30; i++) {
            new Thread(()->{
                list.add(UUID.randomUUID().toString().substring(0,8));
                System.out.println(list);
            }, i+"").start();
        }
    }
}

```





### CopyOnWriteArrayList解析

> CopyOnWriteArrayList  利用的是读写分离的思想，读和写的是不同的容器
>
> 底层使用的是一个Object数组，每次新添加元素的时候利用的是Arrays.copyOf来创建一个新数组达到扩容效果
>
> 使用的是ReentrantLock来保证线程安全
>
> ==写时复制==
> 		Copyonwrite容器即写时复制的容器。往一个容器添加元素的时候，不直接往当前容涨object[]添加，而是先将当前容器    	    object[ ]进行copy，复制出一个新的容器object[ ] newELements，然后新的容器object[ ] newELements里添加元素，添加   		完元素之后，
> 		再将原容器的引用指向新的容器setArray(newELements);。这样做的好处是可以对Copyonwrite容器进行并发的读，而不需		要加锁，因为当前容器不会添加任何元素。所以Copyonwdrite容器也是一种读写分离的思想，读和写不同的容器。





```java
    final transient ReentrantLock lock = new ReentrantLock();  
    private transient volatile Object[] array;
	/**
     * Appends the specified element to the end of this list.
     *
     * @param e element to be appended to this list
     * @return {@code true} (as specified by {@link Collection#add})
     */
    public boolean add(E e) {
        final ReentrantLock lock = this.lock;
        lock.lock();  //锁
        try {
            Object[] elements = getArray();
            int len = elements.length;
            Object[] newElements = Arrays.copyOf(elements, len + 1);  //扩容
            newElements[len] = e;
            setArray(newElements); //将新容器设置为该list的容器
            return true;
        } finally {
            lock.unlock();
        }
    }
```





## HashSet不安全

> HashSet也是线程不安全的，底层没有进行任何线程同步处理。
>
> 在hashset的源码中，底层是用hashmap实现的：
>
> <img src="尚硅谷JUC.assets/image-20210702214003932.png" alt="image-20210702214003932" style="zoom: 67%;" />
>
> 每次add的时候，把值放在了map对象中的key，而map对象的value则全部统一放一个常量：
>
> <img src="尚硅谷JUC.assets/image-20210702214141821.png" alt="image-20210702214141821" style="zoom:67%;" />
>
> <img src="尚硅谷JUC.assets/image-20210702214128420.png" alt="image-20210702214128420" style="zoom:67%;" />
>
> 在下面的demo中，hashset在多线程情况下和arrayList一样会抛出==java.util.ConcurrentModificationException==

```java
package cn.qqncn;

/**
 * @author zkw
 * @Description HashSet不安全
 * @createTime 2021年06月27日 22:56:00
 */
public class ThreadHashSet {
    public static void main(String[] args) {
        Set<String> list = new HashSet<>();
        for (int i = 0; i < 30; i++) {
            new Thread(()->{
                list.add(UUID.randomUUID().toString().substring(0,8));
                System.out.println(list);
            }, i+"").start();
        }
    }
}

```

> 解决方法 使用 ==**CopyOnWriteArraySet**==

```java
public class ThreadHashSet {
    public static void main(String[] args) {
        Set<String> list = new CopyOnWriteArraySet<>();
        for (int i = 0; i < 30; i++) {
            new Thread(()->{
                list.add(UUID.randomUUID().toString().substring(0,8));
                System.out.println(list);
            }, i+"").start();
        }
    }
}
```



## HashMap不安全

> 使用HashMap空参构造，其初始容量是16，负载因子0.75
>
> 初始容量和负载因子都可以自定义，构造方法如下：
>
> <img src="尚硅谷JUC.assets/image-20210702215750931.png" alt="image-20210702215750931" style="zoom: 80%;" />
>
> HashMap同上面两个类一样，在多线程情况下会出现并发修改异常==java.util.ConcurrentModificationException==



**解决方法**：使用==ConcurrentHashMap==

```java
    public static void main(String[] args) {
        Map<String,String> list = new ConcurrentHashMap<>();
        for (int i = 0; i < 30; i++) {
            new Thread(()->{
                list.put(Thread.currentThread().getName(), UUID.randomUUID().toString().substring(0,8));
                System.out.println(list);
            }, i+"").start();
        }
    }
```





## Callable

（第三种线程实现方式）

### Callable与Runnable的区别

> Callable与Runnable的区别
>
> 1. 实现方法名称不一样 
> 2. 有返回值  
> 3. 抛出了异常

```java

class Thread1 implements Runnable{
    @Override
    public void run() {

    }
}

class Thread2 implements Callable<Integer>{
    //1.方法名称不一样  2.有返回值  3.抛出了异常
    @Override
    public Integer call() throws Exception {
        return null;
    }
}

```





### Callable的使用

> ==Callable==线程类的运行，需要依靠==FutureTask==的封装，因为Thread类的构造方法只支持Runnable及其子类，于是就需要继承了Runnable的FutureTast来对Callable子类进行封装，下面是FurtureTast的继承关系源代码：
>
> ```java
> public class FutureTask<V> implements RunnableFuture<V> {
> ```
>
> ```java
> public interface RunnableFuture<V> extends Runnable, Future<V> {
> ```



```java

public class CallableDemo {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        FutureTask<Integer> futureTask = new FutureTask<>(new Thread2());
        new Thread(futureTask).start();
        System.out.println(futureTask.get());
    }
}


class Thread2 implements Callable<Integer>{
    //1.方法名称不一样  2.有返回值  3.抛出了异常
    @Override
    public Integer call() throws Exception {
        System.out.println("come in");
        return 1024;
    }
}

```





### Callable的细节

> 使用callable就相当于==另外==开了一条线程运行，调用get方法就相当于要获取这条线程的运行结果。
>
> **如果在mian线程中调用了get方法，就会阻塞起来等待这个线程的运行结果。**
>
> 于是就出现如下情况：

#### demo1

运行结果：

<img src="尚硅谷JUC.assets/image-20210703004502638.png" alt="image-20210703004502638" style="zoom: 67%;" />

代码：

```java

public class CallableDemo {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        FutureTask<Integer> futureTask = new FutureTask<>(new Thread2());
        new Thread(futureTask).start();
        System.out.println("main");
        System.out.println(futureTask.get()); //后调用get方法
    }
}


class Thread2 implements Callable<Integer>{
    //1.方法名称不一样  2.有返回值  3.抛出了异常
    @Override
    public Integer call() throws Exception {
        Thread.sleep(2000);
        System.out.println("come in");
        return 1024;
    }
}

```



#### demo2

运行结果：

<img src="尚硅谷JUC.assets/image-20210703004655349.png" alt="image-20210703004655349" style="zoom:67%;" />

代码：

```java

public class CallableDemo {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        FutureTask<Integer> futureTask = new FutureTask<>(new Thread2());
        new Thread(futureTask).start();
        System.out.println(futureTask.get()); //先调用get方法，会在这里等待线程返回结果
        System.out.println("main");
    }
}


class Thread2 implements Callable<Integer>{
    //1.方法名称不一样  2.有返回值  3.抛出了异常
    @Override
    public Integer call() throws Exception {
        Thread.sleep(2000);
        System.out.println("come in");
        return 1024;
    }
}


```







### Callable的细节2

> callable多次运行，只会计算一次结果
>
> 

运行结果：（可以看到 ==只执行了一次come in==的输出，即call()这个方法的代码只运行了==一次==）

![image-20210703012507971](尚硅谷JUC.assets/image-20210703012507971.png)

代码：

```java

public class CallableDemo2 {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        FutureTask<Integer> futureTask = new FutureTask<>(new Thread3());
        Thread t1 = new Thread(futureTask);  //第一次调用 这个 futruetask任务
        t1.start();
        Thread t2 = new Thread(futureTask);  //第二次调用 这个 futruetask任务
        t2.start();
        System.out.println(futureTask.get());
        System.out.println(futureTask.get());
        System.out.println("main");
    }
}


class Thread3 implements Callable<Integer>{
    private static int num = 0;
    //1.方法名称不一样  2.有返回值  3.抛出了异常
    @Override
    public Integer call() throws Exception {
        System.out.println("come in");
        return ++num;
    }
}

```



> 原生Thread多次执行start会抛出==IllegalThreadStateException==非法的线程状态异常，Callable也是**一样**
>
> Thread的start() 源码：
>
> ```java
> public synchronized void start() {
>         /**
>          * This method is not invoked for the main method thread or "system"
>          * group threads created/set up by the VM. Any new functionality added
>          * to this method in the future may have to also be added to the VM.
>          *
>          * A zero status value corresponds to state "NEW".
>          */
>         if (threadStatus != 0)
>             throw new IllegalThreadStateException();  //如果线程已经启动，则抛出异常
> 
>         /* Notify the group that this thread is about to be started
>          * so that it can be added to the group's list of threads
>          * and the group's unstarted count can be decremented. */
>         group.add(this);
> 
>         boolean started = false;
>         try {
>             start0();
>             started = true;
>         } finally {
>             try {
>                 if (!started) {
>                     group.threadStartFailed(this);
>                 }
>             } catch (Throwable ignore) {
>                 /* do nothing. If start0 threw a Throwable then
>                   it will be passed up the call stack */
>             }
>         }
>     }
> ```
>
> 





## CountDownLatch

> 倒计时锁存器 用来解决线程执行次序的问题
>
> * CountDownLatch主要有两个方法，当一个或多个线程调用await方法时，这些线程会阻塞。
>
> * 其它线程调用countDown方法会将计数器减1(调用countDown方法的线程不会阻塞)，
>
> * 当计数器的值变为o时，因await方法阻塞的线程会被唤醒，继续执行。
>
>   
>
> 下面例子中，主线程‘班长’需要等子线程全部执行完成再执行，但是出现了如下情况：

运行结果：

<img src="尚硅谷JUC.assets/image-20210703015358674.png" alt="image-20210703015358674" style="zoom:67%;" />

代码：

```java
public class CountDownLatchDemo {
    public static void main(String[] args) {
        for (int i = 0; i < 6; i++) {
            new Thread(()->{
                System.out.println("离开了教室");
            },i+"").start();
        }

        System.out.println("班长关门走人");
    }
}

```



> 解决方法：使用==CountDownLatch==

运行结果：

<img src="尚硅谷JUC.assets/image-20210703015330159.png" alt="image-20210703015330159" style="zoom:67%;" />

代码：

```java
public class CountDownLatchDemo {
    public static void main(String[] args) throws InterruptedException {
        CountDownLatch countDownLatch = new CountDownLatch(6);
        for (int i = 0; i < 6; i++) {
            new Thread(()->{
                System.out.println("离开了教室");
                countDownLatch.countDown();
            },i+"").start();
        }
        countDownLatch.await();
        System.out.println("班长关门走人");

    }
}
```











## CyclicBarrier

---------------------(循环屏障)

> 和上面的CountDownLatch（做减法倒计时开始任务）不同，CyclicBarrier是做加法来开始任务的

运行结果：

<img src="尚硅谷JUC.assets/image-20210703131702320.png" alt="image-20210703131702320" style="zoom:67%;" />

代码：

```java

public class CyclicBarrierDemo {
    public static void main(String[] args) {
        CyclicBarrier cyclicBarrier = new CyclicBarrier(7, ()->{
            System.out.println("召唤神龙");
        });

        for (int i = 0; i < 7; i++) {
            int temp = i;
            new Thread(()->{
                try {
                    System.out.println("集齐第"+temp+"颗龙珠");
                    cyclicBarrier.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (BrokenBarrierException e) {
                    e.printStackTrace();
                }
            },i+"").start();
        }
    }
}
```





## 读写锁ReadWriteLock

> lock锁，只允许一个进程进行读/写
>
> 使用==ReadWriteLock==读写锁，可以实现控制：
>
> 1. 多个线程同时读
> 2. 同一时间只允许一个线程写

下面的demo展示的是，当多个线程要进行同时写操作时，没有加锁的情况，会导致多个线程并发写：

运行结果：

<img src="尚硅谷JUC.assets/image-20210703144213843.png" alt="image-20210703144213843" style="zoom:67%;" />

代码：

```java
/**
 * @author zkw
 * @Description 读写锁
 * @createTime 2021年07月03日 14:30:00
 */
public class ReadWriteLockDemo {
    public static void main(String[] args) {
        MyMap map = new MyMap();

        for (int i = 0; i < 6; i++) {
            new Thread(()->{
                try {
                    map.put(Thread.currentThread().getName(),"");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            },i+"").start();
        }

        for (int i = 0; i < 6; i++) {
            new Thread(()->{
                try {
                    map.get(Thread.currentThread().getName());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            },i+"").start();
        }
    }
}

class MyMap{
    private HashMap<String,String> map = new HashMap<>();

    public void put(String key,String value) throws InterruptedException {
        System.out.println(Thread.currentThread().getName()+"开始写入");
        TimeUnit.SECONDS.sleep(1);
        map.put(key, value);
        System.out.println(Thread.currentThread().getName()+"写入完成");
    }

    public String get(String key) throws InterruptedException {
        System.out.println(Thread.currentThread().getName()+"开始读取");
        TimeUnit.SECONDS.sleep(1);
        String s = map.get(key);
        System.out.println(Thread.currentThread().getName()+"读取完成");
        return s;
    }
}

```



下面使用ReadWriteLock锁对上面的demo进行优化，禁止多个线程同时读的情况，并允许多个线程同时写：

运行结果：

<img src="尚硅谷JUC.assets/image-20210703144534364.png" alt="image-20210703144534364" style="zoom:67%;" />

代码：

```java
/**
 * @author zkw
 * @Description 读写锁
 * @createTime 2021年07月03日 14:30:00
 */
public class ReadWriteLockDemo {
    public static void main(String[] args) {
        MyMap map = new MyMap();

        for (int i = 0; i < 6; i++) {
            new Thread(()->{
                try {
                    map.put(Thread.currentThread().getName(),"");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            },i+"").start();
        }

        for (int i = 0; i < 6; i++) {
            new Thread(()->{
                try {
                    map.get(Thread.currentThread().getName());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            },i+"").start();
        }
    }
}

class MyMap{
    private HashMap<String,String> map = new HashMap<>();
    ReadWriteLock readWriteLock = new ReentrantReadWriteLock();  //创建读写锁
    public void put(String key,String value) throws InterruptedException {
        readWriteLock.writeLock().lock(); //写锁
        System.out.println(Thread.currentThread().getName()+"开始写入");
        TimeUnit.SECONDS.sleep(1);
        map.put(key, value);
        System.out.println(Thread.currentThread().getName()+"写入完成");
        readWriteLock.writeLock().unlock();
    }

    public String get(String key) throws InterruptedException {
        readWriteLock.readLock().lock();  //读锁
        System.out.println(Thread.currentThread().getName()+"开始读取");
        TimeUnit.SECONDS.sleep(1);
        String s = map.get(key);
        System.out.println(Thread.currentThread().getName()+"读取完成");
        readWriteLock.readLock().unlock();
        return s;
    }
}

```





## BlockingQueue(阻塞队列)

### ArrayBlockingQueue 

> ArrayBlockingQueue用于解决多线程问题：生产者消费者案例
>
> ArrayBlockingQueue对象在初始化的时候需要==指定其容量==。
>
> 对于这个队列的操作，给出三种操作方法： 插入、移除、检查
>
> ArrayBlockingQueue对于这三种操作方法，给出了四套解决方案：
>
> 1. 抛出异常（插入时队满，或移除时队空   抛出异常  IllegalStateException：Queue full  或  NoSuchElementExcept）
> 2. 特殊值（插入或移除失败时，返回特殊值：null或false）
> 3. 阻塞（插入或移除失败时，会阻塞等待，等待队列有空位或者有元素）
> 4. 超时（插入或移除失败时，会阻塞等待，等待队列有空位或者有元素，但是可以设置具体超时等待时间）



| 方法类型 | 抛出异常  | 特殊值   | 阻塞   | 超时               |
| :------: | --------- | -------- | ------ | ------------------ |
|   插入   | add(e)    | offer(e) | put(e) | offer(e,time,unit) |
|   移除   | remove()  | poll()   | take() | poll(time,unit)    |
|   检查   | element() | peek()   | 不可用 | 不可用             |

* *检查element()   给出队首的元素*







运行结果：<img src="尚硅谷JUC.assets/image-20210704163325185.png" alt="image-20210704163325185" style="zoom:67%;" />

代码：

```java
package cn.qqncn;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * @author zkw
 * @Description TODO
 * @createTime 2021年07月03日 23:55:00
 */
public class BlockingQueueDemo {
    public static void main(String[] args) throws InterruptedException {
        BlockingQueue<String> blockingQueue = new ArrayBlockingQueue<>(3);

        new Thread(()->{
            for (int i = 0; i < 4; i++) {
                try {
                    blockingQueue.offer(i+"", 3, TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        new Thread(()->{
            for (int i = 0; i < 4; i++) {
                try {
                    System.out.println(blockingQueue.poll(3, TimeUnit.SECONDS));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

    }
}
```







## 线程池

> 线程池的优势：
> 	       线程池做的工作只要是控制运行的线程数量，处理过程中将任务放入队列，然后线程创建石后启动这些任务，==如果线程数量超过了最大数量，超出数量的线程排队等候==，等其他线程执行完毕，再从队列中取出任务来执行。
>
> 它的主要特点为:==线程复用;控制最大并发数;管理线程。==
>
> 第一:降低资源消耗。通过重复利用已创建的线程降低线程创建和销毁造成的销耗。
>
> 第二:提高响应速度。当任务到达时，任务可以不需要等待线程创建就能立即执行。
>
> 第三:提高线程的可管理性。线程是稀缺资源，如果无限制的创建，不仅会销耗系统资源，还会降低系统的稳定性，使用线程池可以进行统一的分配，调优和监控。

### 线程池类的结构：

![image-20210704170559507](尚硅谷JUC.assets/image-20210704170559507.png)

**Executors** 线程池工具类，用来创建线程池实例化





### 固定大小的线程池 FixedThreadPool

运行结果：

> 可以看到，线程池中的三个线程轮流执行任务。

![image-20210704172628321](尚硅谷JUC.assets/image-20210704172628321.png)

代码：

```java

public class ThreadPool {
    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(3);//创建固定大小的线程池
        try {
            for (int i = 0; i < 5; i++) {
                executorService.execute(()->{
                    System.out.println(Thread.currentThread().getName()+"--开始任务");
                });
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            executorService.shutdown();
        }

    }
}

```





### 动态扩容的线程池 CachedThreadPool



运行结果：

> 模拟各个线程排队过来执行任务，线程池只需要开辟一个线程就正好可以一个一个执行任务

<img src="尚硅谷JUC.assets/image-20210704193906722.png" alt="image-20210704193906722" style="zoom:67%;" />

代码：

```java

public class ThreadPool {
    public static void main(String[] args) {
        ExecutorService executorService = Executors.newCachedThreadPool();//创建动态大小的线程池
        try {
            for (int i = 0; i < 5; i++) {
                try {
                    TimeUnit.SECONDS.sleep(1);  //模拟各个线程排队过来执行任务
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                executorService.execute(()->{

                    System.out.println(Thread.currentThread().getName()+"--开始任务");
                });
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            executorService.shutdown();
        }

    }
}

```





运行结果：

> 模拟各个线程同时过来执行任务，线程池同时创建五个线程来执行任务

<img src="尚硅谷JUC.assets/image-20210704194203135.png" alt="image-20210704194203135" style="zoom:67%;" />



代码：

```java
public class ThreadPool {
    public static void main(String[] args) {
        ExecutorService executorService = Executors.newCachedThreadPool();//创建固定大小的线程池
        try {
            for (int i = 0; i < 5; i++) {
                executorService.execute(()->{
                    System.out.println(Thread.currentThread().getName()+"--开始任务");
                });
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            executorService.shutdown();
        }

    }
}

```





## 线程池的底层原理

Executors源码：

```java
    public static ExecutorService newFixedThreadPool(int nThreads) {
        return new ThreadPoolExecutor(nThreads, nThreads,
                                      0L, TimeUnit.MILLISECONDS,
                                      new LinkedBlockingQueue<Runnable>());
    }

    public static ExecutorService newSingleThreadExecutor() {
        return new FinalizableDelegatedExecutorService
            (new ThreadPoolExecutor(1, 1,
                                    0L, TimeUnit.MILLISECONDS,
                                    new LinkedBlockingQueue<Runnable>()));
    }


    public static ExecutorService newCachedThreadPool() {
        return new ThreadPoolExecutor(0, Integer.MAX_VALUE,
                                      60L, TimeUnit.SECONDS,
                                      new SynchronousQueue<Runnable>());
    }

    public ThreadPoolExecutor(int corePoolSize,  	//线程池中的常驻核心线程数
                              int maximumPoolSize,	//线程池能容纳同时执行的最大线程数，此值必须大于等于1
                              long keepAliveTime,	//多余的空闲线程的存活时间，当前池中线程数量超过corePoolSize时，当空闲时间达到keepAliveTime时，多余线程就会被销毁到只剩下corePoolSize为止
                              TimeUnit unit,		//keepAliveTime的单位
                              BlockingQueue<Runnable> workQueue,	//任务队列，被提交但尚未执行的任务
                              ThreadFactory threadFactory,			//创建线程的工厂，默认即可
                              RejectedExecutionHandler handler      //拒绝策略，当队列满（maximumPoolSize）时，根据该handler决定如何拒绝请求执行的runnable
                             ) { 
        .....
            ....
            	...
    }


```



### 线程池工作原理：

**线程池工作图解析：**

![image-20210705223053372](尚硅谷JUC.assets/image-20210705223053372.png)



**线程池工作流程：**

![image-20210705224135061](尚硅谷JUC.assets/image-20210705224135061.png)



**线程池工作流程：**

1、在创建了线程池后，开始等待请求。

2、当调用execute()方法添加一个请求任务时，线程池会做出如下判断:

​	2.1如果正在运行的线程数量小于corePoolSize，那么马上创建线程运行这个任务;

​	2.2如果正在运行的线程数量大于或等corePoolSize，那么将这个任务放入队列;

​	2.3如果这个时候队列满了且正在运行的线程数量还小于maximumPoolSize，那么还是要创建非核心线程立刻运行这个任			务;

​	2.4如果队列满了且正在运行的线程数量大于或等于maximumPoolSize，那么线程池会启动饱和拒绝策略来执行。

3、当一个线程完成任务时，它会从队列中取下一个任务来执行。

4、当一个线程无事可做超过一定的时间（keepAliveTime）时，线程会判断:

如果当前运行的线程数大于corePoolSize，那么这个线程就被停掉。所以线程池的所有任务完成后，它最终会收缩

corePoolSize的大小。





**注意：**

在工作中单一的/固定的/可变的三种创建线程池的方法哪个用的多？

 答： ==一个都不用==

![image-20210705232325132](尚硅谷JUC.assets/image-20210705232325132.png)

OOM  *java虚拟机内存溢出异常*





## 落地实践，线程池在工作中的使用

> 实际开发中，最常用主要还是利用**ThreadPoolExecutor自定义线程池**，可以给出一些关键的参数来自定义。
>
> 在下面的代码中可以看到，该线程池的最大并行线程数是5，线程等候区（阻塞队列)是3，即该线程池最多接受8个线程任务的同时提交。
>
> 一旦超过了8这个任务数，就会抛出==java.util.concurrent.RejectedExecutionException==**拒绝执行异常**

任务数8，运行结果：

<img src="尚硅谷JUC.assets/image-20210706234212808.png" alt="image-20210706234212808" style="zoom:67%;" />

任务数9，运行结果：

<img src="尚硅谷JUC.assets/image-20210706234232532.png" alt="image-20210706234232532" style="zoom:67%;" />

源代码：

```java
package cn.qqncn;

import java.util.concurrent.*;

/**
 * @author zkw
 * @Description 自定义线程池
 * @createTime 2021年07月06日 23:26:00
 */
public class CustomerThreadPool {
    public static void main(String[] args) {
        ExecutorService threadPool = new ThreadPoolExecutor(
                3,                                  //初始线程池并行数
                5,                              //线程池最大并行数
                2L,                                //空闲的线程允许空闲的时间
                TimeUnit.SECONDS,                               //上面参数的单位
                new LinkedBlockingQueue<Runnable>(3),   //设置等候队列长度，不设置的话会默认使用Integer的最大值
                Executors.defaultThreadFactory(),               //创建线程的工厂
                new ThreadPoolExecutor.AbortPolicy());          //拒绝策略

        try {
            for (int i = 0; i < 8; i++) {
                threadPool.execute(()->{
                    System.out.println(Thread.currentThread().getName()+"\t正在服务");
                });
            }

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            threadPool.shutdown();
        }
    }
}

```



## 线程池拒绝策略

**AbortPolicy**(==默认==):直接抛出RejectedExecutionException异常阻止系统正常运行

**CallerRunsPolicy**:“调用者运行”一种调节机制，该策略既不会抛弃任务，也不会抛出异常，而是将某些任务回退到调用者，

而降低新任务的流量。（比如是main线程提交的任务，就回退给main线程执行）

**DiscardOldestPolicy**:抛弃队列中等待最久的任务，然后把当前任务加人队列中尝试再次提交当前任务。

**DiscardPolicy**该策略默默地丢弃无法处理的任务，不予任何处理也不抛出异常。如果允许任务丢失，这是最好的一种策略。



## 线程池参数设置细节

如果任务都是cpu密集型，设置线程池大小的时候应该使用的是根据不同电脑的cpu核数来设置的动态的参数

获取cpu核数：

`Runtime.getRuntime().availableProcessors()`

```java
        ExecutorService threadPool = new ThreadPoolExecutor(
                3,
                Runtime.getRuntime().availableProcessors(),  //根据不同cpu设置的动态线程池大小
                2L,                            
                TimeUnit.SECONDS,                     
                new LinkedBlockingQueue<Runnable>(3),  
                Executors.defaultThreadFactory(),         
                new ThreadPoolExecutor.AbortPolicy());       

```





## （编程篇）函数式接口

> 这块知识主要是在看源代码的时候有用，jdk提供了四大常用的函数式接口

![image-20210707234411363](尚硅谷JUC.assets/image-20210707234411363.png)



## (编程篇)java流式计算Stream

> 流(Stream)到底是什么呢?
> 		是数据渠道，用于操作数据源（集合、数组等）所生成的元素序列。
>
> **“集合讲的是数据，流讲的是计算! ”**

特点：

1. Stream自己不会存储元素。
2. Stream不会改变源对象。相反，他们会返回一个持有结果的新Stream。
3. Stream操作是延迟执行的。这意味着他们会等到需要结果的时候才执行。







下面的代码中，需求是要把list集合中的元素全部变成乘以2，就需要使用map的stream流式计算方法，map接受的是一个JDK提供的，Function接口，所以lambda实现方法时需要一个返回值，一个参数。

map----映射(将元素映射成另外的元素)

collect----stream转list

![image-20210708002719010](尚硅谷JUC.assets/image-20210708002719010.png)





**Stream流就相当于java对集合操作的sql语句，可以进行各种类似sql查询筛选的操作。**

>  * 题目:请按照给出数据，找出同时满足以下条件的用户,也即以下条件全部满足
>  * 偶数工D且年龄大于24且用户名转为大写且用户名字母倒排序
>  * 只输出一个用户名字

运行结果：

<img src="尚硅谷JUC.assets/image-20210708004041264.png" alt="image-20210708004041264" style="zoom:67%;" />

代码：

```java
package cn.qqncn;

import java.util.Arrays;
import java.util.List;

/**
 * 题目:请按照给出数据，找出同时满足以下条件的用户,也即以下条件全部满足
 * 偶数工D且年龄大于24且用户名转为大写且用户名字母倒排序
 * 只输出一个用户名字
 */
public class StreamDemo {
    public static void main(String[] args) {
        User u1 = new User(11, "a", 23);
        User u2 = new User(12, "b", 24);
        User u3 = new User(13, "c", 22);
        User u4 = new User(14, "d", 28);
        User u5 = new User(16, "e", 26);

        List<User> list = Arrays.asList(u1,u2,u3,u4,u5);
        list.stream().filter((u)->{return u.getId()%2==0;})//过滤
                .filter(user -> {return user.getAge()>24;})//过滤
                .map((u)->{return u.getUsername().toUpperCase();})//映射
                .sorted(((o1, o2) -> {return o2.compareTo(o1);}))//排序
                .limit(1)                                   //limit
                .forEach(System.out::println);
    }
}

class User{
    private Integer id;
    private String username;
    private Integer age;

    public User(Integer id, String username, Integer age) {
        this.id = id;
        this.username = username;
        this.age = age;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", age=" + age +
                '}';
    }
}
```



## 分支合并线程池

> 使用场景：例如要计算1到100的累加和，可用创建多个线程，比如让一个线程计算1-50的和，另外一个线程计算51-100的和，然后最终合并两个线程的结果。
>
> 分支合并线程池依然还是线程池Executor的子类。
>
> <img src="尚硅谷JUC.assets/image-20210708170756350.png" alt="image-20210708170756350" style="zoom:67%;" />
>
> 



```java
package cn.qqncn;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveTask;

/**
 * @author zkw
 * @Description 分支合并线程
 * ForkJoinPool 分支合并线程池
 * ForkJoinTask 分支合并任务
 * RecursiveTask 递归任务
 * @createTime 2021年07月08日 16:38:00
 */
public class ForkJoinDemo {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        MyTask myTask = new MyTask(0, 100);
        ForkJoinPool forkJoinPool = new ForkJoinPool();
        ForkJoinTask<Integer> forkJoinTask = forkJoinPool.submit(myTask);
        System.out.println(forkJoinTask.get());
        forkJoinPool.shutdown();
    }
}

class MyTask extends RecursiveTask<Integer>{
    private static final Integer ADJUST_VALUE = 10;

    private int begin;
    private int end;
    private int result;

    public MyTask(int begin, int end) {
        this.begin = begin;
        this.end = end;
    }

    @Override
    protected Integer compute() {
        if((end-begin)<=ADJUST_VALUE){ //如果计算数量小于10，再自己计算
            for (int i = begin; i <= end; i++) {
                result = result+i;
            }
        }else{  //如果计算量大于10，就分支计算
            int middle = (end+begin)/2;
            MyTask myTask = new MyTask(begin, middle);
            MyTask myTask1 = new MyTask(middle+1, end);
            myTask.fork();
            myTask1.fork();
            result = myTask.join()+myTask1.join();
        }
        return result;
    }
}

```



## 异步回调线程

> 设想一个情景，A是处理业务的一个步骤，A需要解决一个问题，这时候A可以问B，让B来告诉A答案，这期间，A可以继续做自己的事情，而不用因为B做的事而阻塞。于是，我们想到给B设置一个线程，让B去处理耗时的操作，然后处理完之后把结果告诉A。所以这个问题的要点就在于B处理完之后如何把结果告诉A。我们可以直接在A中写一个方法对B处理完的结果进行处理，然后B处理完之后调用A这个方法。这样A调用B去处理过程，B调用A的C方法去处理结果就叫做回调。
>
>  
>
> 在正常的业务中使用同步线程，如果服务器每处理一个请求，就创建一个线程的话，会对服务器的资源造成浪费。因为这些线程可能会浪费时间在等待网络传输，等待数据库连接等其他事情上，真正处理业务逻辑的时间很短很短，但是其他线程在线程池满了之后又会阻塞，等待前面的线程处理完成。而且，会出现一个奇怪的现象，客户端的请求被阻塞，但是cpu的资源使用却很低，大部分线程都浪费在处理其他事情上了。所以，这就导致服务器并发量不高。而异步，则可以解决这个问题。我们可以把需要用到cpu的业务处理使用异步来实现，这样其他请求就不会被阻塞，而且cpu会保持比较高的使用率。综上，可以使用回调来实现异步的方法。

关于异步线程的详细博客：     https://www.cnblogs.com/liujiarui/p/13395424.html

![image-20210708191035838](尚硅谷JUC.assets/image-20210708191035838.png)





```java
package cn.qqncn;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

/**
 * @author zkw
 * @Description 异步回调线程
 * @createTime 2021年07月08日 18:48:00
 */
public class CompletableFutureDemo {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        CompletableFuture<Void> completableFuture = CompletableFuture.runAsync(() -> {
            System.out.println("执行任务");
        });
        completableFuture.get();

        CompletableFuture<Integer> supplyAsyncTast = CompletableFuture.supplyAsync(() -> {
            System.out.println("执行有返回值的任务");
//            int result = 1/0;     //抛出异常
            return 1024;
        });

        Integer integer = supplyAsyncTast.whenComplete((t, u) -> {
            System.out.println("t------->" + t);
            System.out.println("u-------》" + u);  //如果抛出异常，这里就会打印异常信息
        }).exceptionally(f -> {
            System.out.println(f);  //如果抛出异常，这里就会打印异常信息
            return 4444;
        }).get();

        System.out.println("supplyAsyncTast:"+integer);
    }

}
```





## JVM

### JVM的位置

> jvm是运行在操作系统之上的，它与硬件没有直接的交互

![image-20210708193207698](尚硅谷JUC.assets/image-20210708193207698.png)



### JVM体系结构

![image-20210708200604195](尚硅谷JUC.assets/image-20210708200604195.png)





### 四大类加载器：

> 详细博客：https://blog.csdn.net/weixin_39683598/article/details/110706492

(1) BootStrap：引导类加载器（加载Object、String类等等）。这个加载器很特殊，它不是JAVA类，因此它不需要被别人加载，它嵌套在JVM内核里，也就是说JVM启动的时候BootStrap就启动了，它是C++写的二进制代码，可以加载别的类。这也是为什么System.class.getClassLoader()结果为null的原因，因为它不是JAVA类，所以它的引用返回null。负责加载核心Java库，存储在<JAVA_HOME>/jre/lib/rt.jar

(2) ExtClassLoader：扩展类加载器。

(3) AppClassLoader：根据类路径来加载java类。一般我们自定义的类都是通过这个AppClassLoader加载。

(4) 自定义类加载器  *public abstract class ClassLoader*

![image-20210708210844347](尚硅谷JUC.assets/image-20210708210844347.png)



> 代码演示查看类加载器：
>
> 可用看到，根加载器打印出来一般都是**null**
>
> 但是可以打印出应用程序类类加载器和扩展类加载器

运行结果：

<img src="尚硅谷JUC.assets/image-20210708235549717.png" alt="image-20210708235549717" style="zoom:67%;" />

代码：

```java
package cn.qqncn;

/**
 * @author zkw
 * @Description JVM三大类加载器
 * @createTime 2021年07月08日 23:50:00
 */
public class ClassLoaderDemo {
    public static void main(String[] args) {
        Object obj = new Object();
        MyClass myClass = new MyClass();
        System.out.println(obj.getClass().getClassLoader());
        System.out.println(myClass.getClass().getClassLoader().getParent().getParent());
        System.out.println(myClass.getClass().getClassLoader().getParent());
        System.out.println(myClass.getClass().getClassLoader());
    }
}
class MyClass{

}

```





### 双亲委派机制

#### 什么是双亲委派机制

当某个类加载器需要加载某个`.class`文件时，它首先把这个任务委托给他的上级类加载器，递归这个操作，如果上级的类加载器没有加载，自己才会去加载这个类。

#### 双亲委派机制的作用

1. 防止重复加载同一个.class。通过委托去向上面问一问，加载过了，就不用再加载一遍。保证数据安全。
2.  保证核心.class不能被篡改。通过委托方式，不会去篡改核心.class，即使篡改也不会去加载，即使加载也不会是同一个.class对象了。不同的加载器加载同一个.class也不是同一个Class对象。这样保证了Class执行安全。



#### 代码演示

> 这里创建了一个java.lang包的String类，来测试类加载器是否是先从BootstrapClassLoader和ExtClassLoader加载的。
>
> 从运行结果可以看出，String这个类首先是委托从根加载器加载的，直接打印了错误信息。这是双亲委派机制的体现。
>
> 也是沙箱[安全机制](https://blog.csdn.net/qq_30336433/article/details/83268945)的体现：
>
> JDK原生类中，拥有较高的本地资源访问权限，类装载器采用的机制是双亲委派模式。
>
> 1. 从最内层JVM自带类加载器开始加载，外层恶意同名类得不到加载从而无法使用；
>
> 2. 由于严格通过包来区分了访问域，外层恶意的类通过内置代码也无法获得权限访问到内层类，破坏代码就自然无法生效。
>
>    即下面的String类无法冒充JDK自带的类，去破坏计算机资源。

运行结果：

<img src="尚硅谷JUC.assets/image-20210709001356595.png" alt="image-20210709001356595" style="zoom:67%;" />

代码：

```java
package java.lang;

/**
 * @author zkw
 * @Description 双亲委派机制演示
 * @createTime 2021年07月09日 00:12:00
 */
public class String {
    public static void main(String[] args) {
        System.out.println("假String");
    }
}

```





#### native

![image-20210709004713824](尚硅谷JUC.assets/image-20210709004713824.png)

> 声明了native的方法，实际上就是代表要去调用操作**系统的本地第三方方法库****(c语言库等)。
>
> 声明了native的方法可以不用实现，只需要有一个方法体。
>
> ![image-20210709003859893](尚硅谷JUC.assets/image-20210709003859893.png)





在Thread类中，start()方法实际上是调用的native声明的==start0()==方法。

<img src="尚硅谷JUC.assets/image-20210709004240936.png" alt="image-20210709004240936" style="zoom:67%;" />

==start0()就是调用的操作系统本地方法库==，不需要在java中有方法实现体.

<img src="尚硅谷JUC.assets/image-20210709004329486.png" alt="image-20210709004329486" style="zoom:67%;" />